version_info = (4, 2, 0)  # pragma: no cover
__version__ = '.'.join(str(v) for v in version_info)  # pragma: no cover
